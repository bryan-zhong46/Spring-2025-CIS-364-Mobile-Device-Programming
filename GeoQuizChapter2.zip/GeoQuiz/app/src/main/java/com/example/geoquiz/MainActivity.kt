package com.example.geoquiz

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar
// 2/20
import com.example.geoquiz.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    // 2/11/25 declare two class data members for two buttons
    // 2/20 private lateinit var trueButton: Button
    // 2/20 private lateinit var falseButton: Button
    // 2/20
    private lateinit var binding: ActivityMainBinding

    // 2/13/25 declare a variable to hold a list of questions
    private val questionBank = listOf(
        Question(R.string.question_australia, true),
        Question(R.string.question_oceans, true),
        Question(R.string.question_mideast, false),
        Question(R.string.question_africa, false),
        Question(R.string.question_americas, true),
        Question(R.string.question_asia, true)
    )

    private var currentIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // 2/20
        // setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // binding the variable with the widget in the layout
        // trueButton = findViewById(R.id.true_button) // R.id lists all the ids
        // falseButton = findViewById(R.id.false_button)

        // listener for process user's click event
        // 2/20 trueButton.setOnClickListener { view: View ->
        binding.trueButton.setOnClickListener { view: View ->
//            Toast.makeText( this,
//                R.string.correct_toast,
//                Toast.LENGTH_SHORT).show()
            checkAnswer(true)
        }

        // 2/20 falseButton.setOnClickListener { view: View ->
        binding.falseButton.setOnClickListener { view: View ->
//            Toast.makeText( this,
//                R.string.incorrect_toast,
//                Toast.LENGTH_SHORT).show()
            checkAnswer(false)
        }

        // 2/20 add listener for next button
        binding.nextButton.setOnClickListener { view: View ->
            currentIndex = (currentIndex + 1) % 6
            updateQuestion()
        }

        // 2/25 add listener for prev button
        binding.prevButton.setOnClickListener { view: View ->
            currentIndex = ((currentIndex - 1) + 6) % 6
            updateQuestion()
        }

        updateQuestion()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // 2/20 add new function to update question when next button is pressed
    private fun updateQuestion() {
        val questionTextResId = questionBank[currentIndex].textResId
        // set the question text
        binding.questionTextView.setText(questionTextResId)
    }

    // 2/20 add function to check if user picks correct answer
    private fun checkAnswer(userAnswer: Boolean) {
        // get the current answer
        val currentAnswer = questionBank[currentIndex].answer
        val messageResId = if (userAnswer == currentAnswer) {
            R.string.correct_toast
        } else {
            R.string.incorrect_toast
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT)
            .show()

    }
}