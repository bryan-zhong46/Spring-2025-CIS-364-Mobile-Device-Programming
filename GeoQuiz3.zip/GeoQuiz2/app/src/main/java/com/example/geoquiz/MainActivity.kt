package com.example.geoquiz

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar
//2/20 import packagename.databinding.ActivityMainBinding
import com.example.geoquiz.databinding.ActivityMainBinding
import com.google.android.material.snackbar.BaseTransientBottomBar
//2/27/205
import android.util.Log
import androidx.activity.viewModels

private const val TAG = "MainActivity"

class MainActivity : AppCompatActivity() {
    //2/11/2025 declare two class data members for two buttons
    //2/20 private lateinit var trueButton: Button
    //2/20 private lateinit var falseButton: Button
    //2/20
    private lateinit var binding: ActivityMainBinding

    //3/4
    private val quizViewModel: QuizViewModel by viewModels()
//3/4 move the question data + index to the QuizViewModel
    /* private val questionBank = listOf(
        Question(R.string.question_australia,true),
        Question(R.string.question_oceans, true),
        Question(R.string.question_mideast, false),
        Question(R.string.question_africa, false),
        Question(R.string.question_americas, true),
        Question(R.string.question_asia, true)
    )
    private var currentIndex = 0

     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate( Bundle?)")
        enableEdgeToEdge()
        //2/20 setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //binding the variable with the widget in the layout
        //2/20 trueButton = findViewById(R.id.true_button)
        //2/20 falseButton = findViewById(R.id.false_button)

        //listener for process the user's click event
        // 2/20 trueButton.setOnClickListener { view: View ->
        binding.trueButton.setOnClickListener { view: View ->
            //Toast.makeText(this,
            //    R.string.correct_toast,
            //    Toast.LENGTH_SHORT).show()
            //
            val snack = Snackbar.make(
                view, "Are you sure with your answer",
                Snackbar.LENGTH_LONG
            ).setAction("Undo",)
             {

                val snackbar = Snackbar.make(
                    view, "No! I want to change my answer! ",
                    Snackbar.LENGTH_LONG
                )
                snackbar.show()
            }
                        snack.show()
            snack.addCallback(object : Snackbar.Callback() {
                override fun onShown(transientBottomBar: Snackbar?) {
                    super.onShown(transientBottomBar)
                }

                override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                    super.onDismissed(transientBottomBar, event)
                   

                }
            })



        }
        //2/20 falseButton.setOnClickListener { view: View ->
        binding.falseButton.setOnClickListener { view: View ->
            /*Toast.makeText(this,
                R.string.incorrect_toast,
                Toast.LENGTH_SHORT).show()*/

            //Snackbar.make(view, "Incorrect!",Snackbar.LENGTH_SHORT).show()
            //checkAnswer(false)


        }

        //2/20
        binding.nextButton.setOnClickListener { view:View ->
            //3/4 currentIndex = (currentIndex +1) % 6
            quizViewModel.moveToNext()
            updateQuestion()
            //val questionTextResId = questionBank[currentIndex].textResId
            //binding.questionTextView.setText(questionTextResId)
        }
        //2/25
        binding.preButton.setOnClickListener { view:View ->
            //3/4 currentIndex = (currentIndex -1 + 6 ) % 6
            quizViewModel.moveToPre()
            updateQuestion()
            //val questionTextResId = questionBank[currentIndex].textResId
            //binding.questionTextView.setText(questionTextResId)
        }

        // 3/13
        binding.cheatButton?.setOnClickListener { view:View ->
            // start the cheat activity
            // step 1: prepare intent object by calling newIntent
            // val intent = Intent(this, CheatActivity::class.java)
            // also pass answer to CheatActivity which is stored in the viewModel
            val answerIsTrue = quizViewModel.currentQuestionAnswer
            val intent = CheatActivity.newIntent(this, answerIsTrue)
            startActivity(intent)
        }

        //val questionTextResId = questionBank[currentIndex].textResId
        //set the question text
        //binding.questionTextView.setText(questionTextResId)
        updateQuestion()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    //2/20
    private fun updateQuestion()
    {
        //3/4 val questionTextResId = questionBank[currentIndex].textResId
        val questionTextResId = quizViewModel.currentQuestionText
        //set the question text
        binding.questionTextView.setText(questionTextResId)
    }
    //2/20
    private fun checkAnswer(userAnswer: Boolean)
    {
        //what is the correct answer
        //3/4 val currentAnswer = questionBank[currentIndex].answer
        val currentAnswer = quizViewModel.currentQuestionAnswer
        val messageResId =
            if (userAnswer == currentAnswer) {
                R.string.correct_toast
            }
            else
            {
                R.string.incorrect_toast
            }
        Toast.makeText(this, messageResId, Toast.LENGTH_LONG)
            .show()
    }
    //2/27/2025
    override fun onStart() {
        super.onStart()
        Log.d(TAG,"onStart()")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume()")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "OnPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG,"onStop()")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy()")
    }

}